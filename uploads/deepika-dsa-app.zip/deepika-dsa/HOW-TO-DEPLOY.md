# 🚀 Deploy Deepika's DSA App — Step by Step Guide
## Takes about 10 minutes. Free forever!

---

## WHAT YOU'LL GET
✅ A live website like: **deepika-dsa.vercel.app**
✅ Installable on your phone (like a real app with icon)
✅ Push notifications that ping your phone daily
✅ Works offline too!

---

## STEP 1 — Upload to GitHub

1. Go to **github.com** and log in (you already have an account ✅)
2. Click the **"+"** button (top right) → **"New repository"**
3. Name it: `deepika-dsa`
4. Set to **Public**
5. Click **"Create repository"**
6. On the next page, click **"uploading an existing file"**
7. **Drag and drop ALL these files** into the upload area:
   - `index.html`
   - `sw.js`
   - `manifest.json`
   - `icon-192.png`
   - `icon-512.png`
8. Click **"Commit changes"** (green button)

---

## STEP 2 — Deploy on Vercel (Free)

1. Go to **vercel.com**
2. Click **"Sign Up"** → choose **"Continue with GitHub"**
3. Allow Vercel to access your GitHub
4. Click **"Add New Project"**
5. Find your **deepika-dsa** repo and click **"Import"**
6. Leave all settings as default
7. Click **"Deploy"** 🚀

⏳ Wait ~30 seconds...

8. Vercel will show you your live URL like:
   **`https://deepika-dsa.vercel.app`** 🎉

---

## STEP 3 — Install on Your Phone

### Android:
1. Open your Vercel URL in **Chrome**
2. You'll see a banner at the bottom: **"Add to Home Screen"**
3. Tap it → tap **"Install"**
4. Done! The app icon appears on your home screen 📱

### iPhone/iPad:
1. Open your Vercel URL in **Safari** (must be Safari!)
2. Tap the **Share button** (box with arrow pointing up ↑)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **"Add"**
5. Done! App icon on home screen 📱

---

## STEP 4 — Enable Notifications on Phone

1. Open the installed app from your home screen
2. Go to the **Reminders** tab (🔔)
3. Set your preferred time (e.g., 8:00 PM)
4. Tap **"Enable"**
5. When your phone asks "Allow Notifications?" → tap **Allow**

✅ You'll now get a notification at that time EVERY DAY!

---

## STEP 5 — Test It Works

In the Reminders tab, tap **"Send Test Notification"**
→ You should see a notification pop up on your screen immediately!

---

## 🆓 Cost: Completely FREE
- GitHub: Free
- Vercel: Free (100GB bandwidth/month — way more than you need)
- Notifications: Free (uses browser push, no SMS cost)

---

## 🔄 Updating the App Later

If you want to make changes:
1. Edit your files
2. Go to your GitHub repo
3. Click the file → click the ✏️ pencil icon → edit → commit
4. Vercel **automatically redeploys** in ~30 seconds!

---

## ❓ Troubleshooting

**Notifications not working on iPhone?**
→ Make sure you opened in Safari (not Chrome) and installed to home screen first

**App not installing on Android?**
→ Make sure you're using Chrome, not Samsung Browser or Firefox

**Can't find the Vercel URL?**
→ Log into vercel.com → click your project → the URL is at the top

---

## 🎉 YOU'RE DONE!
Your personal DSA app is live. Share the link with no one — this is YOUR app, Deepika!
Good luck cracking that placement! 💪
