#!/usr/bin/env python3
# generate-icons.py - run once to create PNG icons
# pip install Pillow
from PIL import Image, ImageDraw, ImageFont
import os

def make_icon(size, filename):
    img = Image.new('RGBA', (size, size), (0,0,0,0))
    draw = ImageDraw.Draw(img)
    # Coral background circle
    draw.ellipse([0,0,size-1,size-1], fill='#e8604c')
    # Book emoji approximation - white rectangle pages
    m = int(size * 0.2)
    w = size - 2*m
    h = int(w * 1.1)
    top = (size - h) // 2
    # Left page
    draw.rectangle([m, top, size//2 - 2, top+h], fill='white')
    # Right page
    draw.rectangle([size//2 + 2, top, size-m, top+h], fill='#fff0e8')
    # Spine
    draw.rectangle([size//2-3, top, size//2+3, top+h], fill='#e8604c')
    img.save(filename, 'PNG')
    print(f'Created {filename}')

make_icon(192, 'icon-192.png')
make_icon(512, 'icon-512.png')
