// sw.js - Service Worker for Deepika's DSA App
// Handles push notifications + offline caching

const CACHE_NAME = 'deepika-dsa-v1';
const ASSETS = ['/', '/index.html', '/manifest.json'];

// ── Install: cache core assets ──────────────────────────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

// ── Activate: clean old caches ───────────────────────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ── Fetch: serve from cache, fallback to network ─────────────────────────────
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(r => r || fetch(event.request))
  );
});

// ── Push: show notification when pushed from server ──────────────────────────
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || '📚 Deepika, time to study!';
  const options = {
    body: data.body || 'Your 30-min DSA session awaits. Keep the streak alive! 🔥',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || '/' },
    actions: [
      { action: 'open',    title: '📖 Start Studying' },
      { action: 'dismiss', title: '⏰ Remind Later'   }
    ]
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// ── Notification click ───────────────────────────────────────────────────────
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'dismiss') return;
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      const existing = list.find(c => c.url.includes(self.location.origin));
      if (existing) { existing.focus(); return; }
      clients.openWindow(event.notification.data.url || '/');
    })
  );
});

// ── Scheduled local alarm (checked every minute via message) ─────────────────
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'CHECK_ALARM') {
    const { time, progress } = event.data;
    const now = new Date();
    const hhmm = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0');
    if (hhmm === time) {
      self.registration.showNotification('📚 Deepika, study time! 🔥', {
        body: `You're ${progress}% done with your DSA journey. 30 mins today = dream job tomorrow!`,
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        vibrate: [200, 100, 200, 100, 200],
        actions: [
          { action: 'open', title: '📖 Open App' }
        ]
      });
    }
  }
});
