# QuantumReady — Post-Quantum Cryptography Migration Assistant
# ProtoSpark 2026

## Project Structure

```
quantumready/
├── backend/
│   ├── main.py                  # FastAPI server (all API endpoints)
│   ├── scanner/
│   │   └── engine.py            # Core AST vulnerability scanner
│   └── ai/
│       └── fix_suggester.py     # Quantum-safe fix generator
├── frontend/
│   └── index.html               # Complete frontend (works standalone)
├── sample/
│   └── vulnerable_app.py        # Demo file with vulnerabilities
└── README.md
```

## Modules Explained

### 1. Scanner Engine (backend/scanner/engine.py)
- Parses Python code using regex pattern matching
- Detects: RSA, ECC, MD5, SHA1, weak TLS, legacy ciphers
- Returns: vulnerability list with line numbers, risk levels, descriptions
- Scoring: starts at 100, deducts points per vulnerability found

### 2. AI Fix Suggester (backend/ai/fix_suggester.py)
- Maps each vulnerability type to a NIST-approved quantum-safe fix
- Provides: fixed code, algorithm name, why it's safe
- Uses CRYSTALS-Kyber, CRYSTALS-Dilithium, SHA3-256, TLS 1.3
- Works offline (no API key needed for basic fixes)

### 3. FastAPI Backend (backend/main.py)
- POST /scan        → upload .py file, get vulnerability report
- POST /scan/code   → scan raw code string
- POST /fix         → get fix for specific vulnerability
- POST /fix/all     → get fixes for all vulnerabilities
- GET  /demo        → run scanner on built-in demo file
- GET  /algorithms  → list all NIST PQC algorithms

### 4. Frontend (frontend/index.html)
- Standalone HTML — works without backend (uses built-in JS scanner)
- Features: file upload, drag & drop, demo mode
- Shows: risk score gauge, vulnerability cards, code diff, fixes
- Built with: vanilla JS, Google Fonts, CSS animations

## Quick Start

### Frontend Only (No setup needed)
Open frontend/index.html in any browser.
Click "Run Demo" to see a live scan.

### Full Stack
```bash
# Backend
cd backend
pip install fastapi uvicorn python-multipart
python main.py

# Frontend
open frontend/index.html
# Change fetch URL to http://localhost:8000
```

## Vulnerability Types Detected
| Type | Risk | Algorithm Broken By |
|------|------|-------------------|
| RSA Key Generation | CRITICAL | Shor's Algorithm |
| RSA Library Import | CRITICAL | Shor's Algorithm |
| ECC Key Generation | CRITICAL | Shor's Algorithm |
| ECC Curve Usage | CRITICAL | Shor's Algorithm |
| MD5 Hash | HIGH | Classical + Grover's |
| SHA1 Hash | HIGH | Classical collision |
| Weak TLS | HIGH | Multiple attacks |
| Legacy Ciphers | MEDIUM | Brute force |

## NIST Standards Used
- FIPS 203: CRYSTALS-Kyber (Key Encapsulation)
- FIPS 204: CRYSTALS-Dilithium (Digital Signatures)
- FIPS 205: SPHINCS+ (Hash-based Signatures)
- FIPS 202: SHA-3 (Hash Functions)

## Team
ProtoSpark 2026 — Software Category
