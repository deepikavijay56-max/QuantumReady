# scanner/engine.py - Core AST-based vulnerability scanner

import ast
import re
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class Vulnerability:
    line_number: int
    vulnerable_code: str
    vulnerability_type: str
    risk_level: str  # CRITICAL, HIGH, MEDIUM, LOW
    description: str
    fix_hint: str
    score_penalty: int

# Vulnerability patterns to detect
VULNERABILITY_PATTERNS = [
    {
        "pattern": r"RSA\.generate\(",
        "type": "RSA Key Generation",
        "risk": "CRITICAL",
        "description": "RSA encryption will be broken by quantum computers using Shor's Algorithm. Any data protected by RSA becomes readable once quantum computers reach sufficient power.",
        "fix_hint": "Replace with KYBER512 (for encryption) or DILITHIUM3 (for signatures) from liboqs-python",
        "penalty": 25
    },
    {
        "pattern": r"from Crypto\.PublicKey import RSA",
        "type": "RSA Library Import",
        "risk": "CRITICAL",
        "description": "This library uses RSA cryptography which is vulnerable to quantum attacks via Shor's Algorithm.",
        "fix_hint": "Replace with: from oqs import KeyEncapsulation and use Kyber512",
        "penalty": 25
    },
    {
        "pattern": r"from cryptography\.hazmat\.primitives\.asymmetric import rsa",
        "type": "RSA Asymmetric Import",
        "risk": "CRITICAL",
        "description": "RSA asymmetric encryption is quantum-vulnerable. Shor's algorithm can factor RSA keys in polynomial time.",
        "fix_hint": "Use post-quantum KEM: from oqs import KeyEncapsulation('Kyber512')",
        "penalty": 25
    },
    {
        "pattern": r"ECC\.generate\(",
        "type": "ECC Key Generation",
        "risk": "CRITICAL",
        "description": "Elliptic Curve Cryptography is also broken by quantum computers. Shor's algorithm solves the discrete logarithm problem ECC relies on.",
        "fix_hint": "Replace with DILITHIUM3 for signatures or KYBER512 for key exchange",
        "penalty": 25
    },
    {
        "pattern": r"curve='P-256'|curve='P-384'|curve='secp256k1'",
        "type": "ECC Curve Usage",
        "risk": "CRITICAL",
        "description": "NIST P-curves and secp256k1 are all vulnerable to quantum attacks. These are widely used in TLS and blockchain systems.",
        "fix_hint": "Replace with CRYSTALS-Dilithium for digital signatures",
        "penalty": 25
    },
    {
        "pattern": r"hashlib\.md5\(",
        "type": "MD5 Hash Function",
        "risk": "HIGH",
        "description": "MD5 is cryptographically broken even on classical computers. Collision attacks have been demonstrated. Never use for passwords or integrity checks.",
        "fix_hint": "Replace with hashlib.sha3_256() or hashlib.blake2b()",
        "penalty": 15
    },
    {
        "pattern": r"hashlib\.sha1\(",
        "type": "SHA1 Hash Function",
        "risk": "HIGH",
        "description": "SHA1 has known collision vulnerabilities (SHAttered attack). Google demonstrated a practical collision attack in 2017.",
        "fix_hint": "Replace with hashlib.sha3_256() for quantum resistance",
        "penalty": 15
    },
    {
        "pattern": r"PROTOCOL_TLSv1(?!_2|_3)",
        "type": "Weak TLS Version",
        "risk": "HIGH",
        "description": "TLS 1.0 and 1.1 are deprecated and vulnerable to multiple attacks including BEAST and POODLE.",
        "fix_hint": "Use ssl.PROTOCOL_TLS_CLIENT with minimum_version=ssl.TLSVersion.TLSv1_3",
        "penalty": 15
    },
    {
        "pattern": r"DES\.|3DES\.|Blowfish\.",
        "type": "Legacy Symmetric Cipher",
        "risk": "MEDIUM",
        "description": "DES, 3DES and Blowfish have small key sizes insufficient for long-term security against quantum or classical attacks.",
        "fix_hint": "Replace with AES-256-GCM for symmetric encryption",
        "penalty": 8
    },
    {
        "pattern": r"key_size=1024|bits=1024|RSA.*1024",
        "type": "Weak RSA Key Size",
        "risk": "MEDIUM",
        "description": "1024-bit RSA keys can be factored by classical computers. Minimum should be 4096-bit, but RSA itself is quantum-vulnerable.",
        "fix_hint": "Migrate entirely to post-quantum cryptography with KYBER512",
        "penalty": 8
    },
]

def calculate_score(vulnerabilities: List[Vulnerability]) -> int:
    score = 100
    for v in vulnerabilities:
        score -= v.score_penalty
    return max(0, score)

def get_risk_label(score: int) -> str:
    if score >= 80:
        return "SAFE"
    elif score >= 60:
        return "MODERATE RISK"
    elif score >= 40:
        return "HIGH RISK"
    else:
        return "CRITICAL RISK"

def scan_code(code: str, filename: str = "uploaded_file.py") -> dict:
    vulnerabilities = []
    lines = code.split('\n')

    for line_num, line in enumerate(lines, start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            continue

        for pattern_info in VULNERABILITY_PATTERNS:
            if re.search(pattern_info["pattern"], line):
                vuln = Vulnerability(
                    line_number=line_num,
                    vulnerable_code=line.strip(),
                    vulnerability_type=pattern_info["type"],
                    risk_level=pattern_info["risk"],
                    description=pattern_info["description"],
                    fix_hint=pattern_info["fix_hint"],
                    score_penalty=pattern_info["penalty"]
                )
                vulnerabilities.append(vuln)

    score = calculate_score(vulnerabilities)
    risk_label = get_risk_label(score)

    # Count by risk level
    counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for v in vulnerabilities:
        counts[v.risk_level] = counts.get(v.risk_level, 0) + 1

    return {
        "filename": filename,
        "score": score,
        "risk_label": risk_label,
        "total_vulnerabilities": len(vulnerabilities),
        "vulnerability_counts": counts,
        "vulnerabilities": [
            {
                "line_number": v.line_number,
                "vulnerable_code": v.vulnerable_code,
                "vulnerability_type": v.vulnerability_type,
                "risk_level": v.risk_level,
                "description": v.description,
                "fix_hint": v.fix_hint,
                "score_penalty": v.score_penalty
            }
            for v in vulnerabilities
        ]
    }


if __name__ == "__main__":
    # Test with sample file
    with open("../sample/vulnerable_app.py", "r") as f:
        code = f.read()
    
    result = scan_code(code, "vulnerable_app.py")
    print(f"\n🔍 SCAN COMPLETE")
    print(f"Score: {result['score']}/100")
    print(f"Risk: {result['risk_label']}")
    print(f"Total Vulnerabilities: {result['total_vulnerabilities']}")
    print(f"Breakdown: {result['vulnerability_counts']}")
    print(f"\nVulnerabilities Found:")
    for v in result['vulnerabilities']:
        print(f"  Line {v['line_number']}: [{v['risk_level']}] {v['vulnerability_type']}")
        print(f"    Code: {v['vulnerable_code']}")
        print(f"    Fix: {v['fix_hint']}")
        print()
