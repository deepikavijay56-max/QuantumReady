# main.py - FastAPI Backend Server for QuantumReady

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import sys
import os

sys.path.append(os.path.dirname(__file__))
from scanner.engine import scan_code
from ai.fix_suggester import get_quantum_safe_fix

app = FastAPI(
    title="QuantumReady API",
    description="Post-Quantum Cryptography Migration Assistant",
    version="1.0.0"
)

# CORS - allow frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class FixRequest(BaseModel):
    vulnerability_type: str
    vulnerable_code: str

@app.get("/")
def root():
    return {"message": "QuantumReady API is running 🔐", "version": "1.0.0"}

@app.post("/scan")
async def scan_file(file: UploadFile = File(...)):
    """Scan an uploaded Python file for quantum-vulnerable encryption."""
    
    if not file.filename.endswith('.py'):
        raise HTTPException(status_code=400, detail="Only Python (.py) files are supported")
    
    content = await file.read()
    code = content.decode('utf-8')
    
    result = scan_code(code, file.filename)
    return JSONResponse(content=result)

@app.post("/scan/code")
async def scan_code_snippet(payload: dict):
    """Scan a raw code string (for demo/testing)."""
    code = payload.get("code", "")
    filename = payload.get("filename", "snippet.py")
    result = scan_code(code, filename)
    return JSONResponse(content=result)

@app.post("/fix")
async def get_fix(request: FixRequest):
    """Get quantum-safe fix for a specific vulnerability."""
    fix = get_quantum_safe_fix(request.vulnerability_type, request.vulnerable_code)
    return JSONResponse(content=fix)

@app.post("/fix/all")
async def get_all_fixes(payload: dict):
    """Get fixes for all vulnerabilities in a scan result."""
    vulnerabilities = payload.get("vulnerabilities", [])
    fixes = []
    for vuln in vulnerabilities:
        fix = get_quantum_safe_fix(vuln["vulnerability_type"], vuln["vulnerable_code"])
        fixes.append({**vuln, "fix": fix})
    return JSONResponse(content={"fixes": fixes})

@app.get("/demo")
async def demo_scan():
    """Run scanner on the built-in demo vulnerable file."""
    demo_path = os.path.join(os.path.dirname(__file__), "../sample/vulnerable_app.py")
    with open(demo_path, "r") as f:
        code = f.read()
    result = scan_code(code, "vulnerable_app.py")
    return JSONResponse(content=result)

@app.get("/algorithms")
def list_algorithms():
    """List all NIST-approved post-quantum algorithms."""
    return {
        "key_encapsulation": [
            {"name": "CRYSTALS-Kyber512", "standard": "NIST FIPS 203", "security_level": "128-bit quantum", "replaces": "RSA-2048"},
            {"name": "CRYSTALS-Kyber768", "standard": "NIST FIPS 203", "security_level": "192-bit quantum", "replaces": "RSA-3072"},
            {"name": "CRYSTALS-Kyber1024", "standard": "NIST FIPS 203", "security_level": "256-bit quantum", "replaces": "RSA-4096"},
        ],
        "digital_signatures": [
            {"name": "CRYSTALS-Dilithium2", "standard": "NIST FIPS 204", "security_level": "128-bit quantum", "replaces": "ECDSA-256"},
            {"name": "CRYSTALS-Dilithium3", "standard": "NIST FIPS 204", "security_level": "192-bit quantum", "replaces": "ECDSA-384"},
            {"name": "SPHINCS+-SHA2-128s", "standard": "NIST FIPS 205", "security_level": "128-bit quantum", "replaces": "RSA-SHA256"},
        ],
        "hash_functions": [
            {"name": "SHA3-256", "standard": "NIST FIPS 202", "security_level": "128-bit quantum", "replaces": "SHA1/MD5"},
            {"name": "SHA3-512", "standard": "NIST FIPS 202", "security_level": "256-bit quantum", "replaces": "SHA256"},
            {"name": "BLAKE3", "standard": "Community", "security_level": "128-bit quantum", "replaces": "MD5/SHA1"},
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
