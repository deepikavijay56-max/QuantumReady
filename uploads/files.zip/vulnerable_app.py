# vulnerable_app.py - Sample application with weak encryption (FOR DEMO PURPOSES)

import hashlib
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA1
import ssl

# ❌ CRITICAL: RSA key generation - vulnerable to quantum attacks
def generate_user_keypair():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key

# ❌ CRITICAL: RSA encryption for sensitive data
def encrypt_patient_data(data: bytes, public_key_bytes: bytes):
    public_key = RSA.import_key(public_key_bytes)
    cipher = PKCS1_OAEP.new(public_key)
    encrypted = cipher.encrypt(data)
    return encrypted

# ❌ HIGH: MD5 hashing for passwords - easily breakable
def hash_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()

# ❌ HIGH: SHA1 for file integrity - collision-vulnerable
def verify_file_integrity(file_bytes: bytes) -> str:
    return hashlib.sha1(file_bytes).hexdigest()

# ❌ CRITICAL: ECC digital signature
def sign_transaction(private_key, transaction_data):
    from Crypto.PublicKey import ECC
    key = ECC.generate(curve='P-256')
    return key

# ❌ MEDIUM: Weak SSL/TLS version
def create_ssl_context():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    return ctx

# Safe function (no issues)
def process_user_request(user_id: str, payload: dict):
    print(f"Processing request for {user_id}")
    return payload
